use TESTDB
go

insert into dbo.TEST_TABLE(TEST_FIELD1) values ('1')
go